<?php

namespace Tests\Feature\Exercise;

use App\Notion;
use App\Exercise;
use Tests\TestCase;
use App\ExerciseNotion;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;

class ExerciseNotionTest extends TestCase
{
    use RefreshDatabase;


    /** @test **/
    public function add_notions_to_an_exercise()
    {
        $this->withoutExceptionHandling();
        $result = $this->createExerciseForChapter();
    
        $response = $this->actingAs($result['teacher']->user)->post(
            route('exercises.notions.store',["exercise"=>Exercise::first()->id]),
            ["notions" => \factory(ExerciseNotion::class,4)->make()->toArray()]
        );

        $response->assertStatus(Response::HTTP_CREATED);

        $this->assertTrue(Exercise::first()->notions->count()===4);
    }

    /** @test **/
    public function add_existing_notions_to_an_exercise()
    {
        $this->withoutExceptionHandling();
        $result = $this->createExerciseForChapter();
        $exercise = Exercise::first();
        
        $exerciseNotion = \factory(ExerciseNotion::class)->make();
        
        $exerciseNotion->value = Notion::create([
            'title'=>'Test',
            'matiere_id'=>$exercise->exercisable->matiere->id,
            'teacher_id'=>$exercise->exercisable->teacher->id
        ])->id;

        $response = $this->actingAs($result['teacher']->user)->post(
            route('exercises.notions.store',["exercise"=>$exercise->id]),
            ["notions" => [$exerciseNotion->toArray()]]
        );

        $response->assertStatus(Response::HTTP_CREATED);

        $this->assertTrue($exercise->notions->count()===1);
    }
}