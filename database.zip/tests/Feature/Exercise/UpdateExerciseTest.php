<?php

namespace Tests\Feature\Exercise;


use App\Chapter;
use App\Exercise;
use Tests\TestCase;
use App\Referentiel;
use App\Constants\CodeReferentiel;
use App\Constants\TypeReferentiel;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;

class UpdateExerciseTest extends TestCase
{
    use RefreshDatabase;


    /** @test **/
    public function update_exercise_type()
    {
        $this->withoutExceptionHandling();
        
        $result = $this->createExerciseForChapter();
    
        $type = Referentiel::firstOrCreate([
            'code' => CodeReferentiel::PROBLEM,
            'type' => TypeReferentiel::EXERCISE
        ],['name' => 'Test',]);

        $response = $this->actingAs($result['teacher']->user)->put(
            route('exercises.update',[ "exercise"=> $result['exercise']->id]),
            [
                "type" => $type->id
            ]
        );

        $exercise = Exercise::first();
        $this->assertTrue($type->id==$exercise->type->id);
    }

    /** @test **/
    public function active_exercise()
    {
        $this->withoutExceptionHandling();
        
        $result = $this->createExerciseForChapter();
    
        $response = $this->actingAs($result['teacher']->user)->put(
            route('exercises.update',[ "exercise"=> $result['exercise']->id]),
            ["active" => 1]
        );

        $exercise = Exercise::first();
        $this->assertTrue($exercise->active==1);
        $this->assertTrue($exercise->content->active==1);
        $this->assertTrue($exercise->solution->content->active==1);
    }

}