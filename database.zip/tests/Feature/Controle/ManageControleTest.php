<?php

namespace Tests\Feature\Controle;

use App\Matiere;
use App\Teacher;
use App\Controle;
use Tests\TestCase;
use App\Referentiel;
use App\Http\Resources\ControleResource;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Foundation\Testing\RefreshDatabase;


class ManageControleTest extends TestCase
{
    use RefreshDatabase;

    /** @test **/
    public function a_teacher_can_create_controle()
    {
        $this->withoutExceptionHandling();
        
        $result = $this->createControle();

        $result['response']
            ->assertStatus(Response::HTTP_CREATED);
    }


    /** @test **/
    public function a_teacher_can_update_her_controle()
    {
        $this->withoutExceptionHandling();

        $result = $this->createControle();

        $controle = Controle::first();
        $controle->active = 0;
        $controle->year = 2019;
       
        $response = $this->actingAs($result['teacher']->user)->put(
            route('controles.update',["controle"=>$controle->id]),
            $controle->toArray()
        );

        $response
            ->assertStatus(Response::HTTP_CREATED)
            ->assertJson($this->decodeResource(new ControleResource($controle)));
    }

    /** @test **/
    public function a_teacher_can_update_only_her_controle()
    {

        $result = $this->createControle();

        $controle = Controle::first();
        $controle->active = 0;

        $teacher = factory(Teacher::class)->create();

        $response = $this->actingAs($teacher->user)->put(
            route('controles.update',["controle"=>$controle->id]),
            $controle->toArray()
        );
        
        $response->assertStatus(Response::HTTP_UNAUTHORIZED);

    }


    /** @test **/
    public function privilege_exception_if_teacher_matiere_not_valide_on_creating()
    {
        //$this->withoutExceptionHandling();

        $teacher = factory(Teacher::class)->create();

        $controle = factory(Controle::class)->make();

        $controle->teacher = $teacher->id;
        
        $response = $this->actingAs($teacher->user)->post(
            route('controles.store'),
            array_merge($controle->toArray(),[
                'matiere' => [
                    'id' => $controle->matiere,
                ],
                'classe' => [
                    'id' => $controle->classe
                ]
            ])
        );
        
        $response->assertStatus(Response::HTTP_UNAUTHORIZED);

    }

    
    /** @test **/
    public function privilege_exception_if_teacher_matiere_not_valide_on_updating()
    {
        //$this->withoutExceptionHandling();

        $result = $this->createControle();

        $matiere = factory(Matiere::class)->create();

        $result['teacher']->matieres()->attach($matiere->id,[
            'etat_id' => \factory(Referentiel::class)->create()->id,
            'justificatif' => 'justificatif.pdf'
        ]);
        $controle = Controle::first();
                
        $response = $this->actingAs($result['teacher']->user)->put(
            route('controles.update',['controle'=>$controle->id]),
            [
                "matiere" =>[
                    'id' =>  $matiere->id
                ]
            ]
        );
        
        $response->assertStatus(Response::HTTP_UNAUTHORIZED);

    }


    /** @test **/
    public function a_controle_field_can_be_update()
    {
        $result = $this->createControle();

        $response = $this->actingAs($result['teacher']->user)->put(
            route('controles.update',["controle"=>Controle::first()->id]),
            ['year'=>2019]
        );

        $response->assertStatus(Response::HTTP_CREATED);
    }

}
