<?php

namespace Tests;

use App\Book;
use App\User;
use App\Admin;
use App\Option;
use App\Chapter;
use App\Student;
use App\Teacher;
use App\Controle;
use App\Exercise;
use App\Specialite;
use App\Constants\CodeReferentiel;
use Illuminate\Foundation\Testing\TestCase as BaseTestCase;

abstract class TestCase extends BaseTestCase
{
    use CreatesApplication;

    protected function decodeResource($resource){
        return json_decode($resource->response()->getContent(), true);
    }

    protected function createAdmin(){
        $admin = new Admin();
        $admin->save();
        $admin->user()->save($user = factory(User::class)->make());
        return $admin;
    }

    protected function makeStudent(){
        $student = factory(Student::class)->make();
        $user = factory(User::class)->make();
        return $this->post(route('students.store'),
            array_merge(
                $student->toArray(),
                $user->toArray()
            )
        );
    }

    protected function createStudent($size=1){
        if($size==1){
            return $this->makeStudent();
        }
        for ($i=0; $i < $size; $i++) { 
            $this->makeStudent();
        }
    }

    protected function createTeacher(){
        $user = factory(User::class)->make();
        $teacher = factory(Teacher::class)->make();
        
        $teacher->user = $user;

        $response = $this->post(route('teachers.store'),array_merge(
            $user->toArray(),
            $teacher->toArray()
        ));

        return [
            'teacher' => $teacher,
            'response' => $response
        ];
    }

    protected function createControle($t = null){

        $this->createTeacher();
        
        $teacher = $t==null ? Teacher::first() : $t;

        $controle = factory(Controle::class)->make();

        
        $matiereId = $teacher->matieres->first()->id;
        
        $Specialite = Specialite::where('matiere_id',$matiereId)->first();
        
        $controle->matiere = [
            'id' => $matiereId,
            'specialite' => isset($Specialite) ? $Specialite->id : null
        ];

        $controle->classe = [
            'id' => $controle->classe,
            'option' =>  Option::where('classe_id',$controle->classe)->first()->id
        ];

        $controle->teacher = $teacher->id;

        $controle->type = CodeReferentiel::DEVOIR;

        
        $response = $this->actingAs($teacher->user)
            ->post(route('controles.store'),$controle->toArray());

        return  [
            "controle" => $controle,
            "teacher" => $teacher,
            "response" => $response
        ];
    }

    protected function createBook($t = null){

        $teacher = $t==null ? factory(Teacher::class)->create() : $t;

        $book = factory(Book::class)->make();
        
        $matiereId = $teacher->matieres->first()->id;
        
        $Specialite = Specialite::where('matiere_id',$matiereId)->first();
        
        $book->matiere = [
            'id' => $matiereId,
            'specialite' => isset($Specialite) ? $Specialite->id : null
        ];
        
        $book->classes = [[
            'id' => $book->classes,
        ]];

        $book->teacher = $teacher->id;
        
        //dd($book->toArray());
        $response = $this->actingAs($teacher->user)
            ->post(route('books.store'),$book->toArray());

        return  [
            "book" => $book,
            "teacher" => $teacher,
            "response" => $response
        ];
    }


    protected function createChapter($t = null){

        $teacher = $t==null ? factory(Teacher::class)->create() : $t;

        $chapter = factory(Chapter::class)->make();

        
        $matiereId = $teacher->matieres->first()->id;
        
        $Specialite = Specialite::where('matiere_id',$matiereId)->first();
        
        $chapter->matiere = [
            'id' => $matiereId,
            'specialite' => isset($Specialite) ? $Specialite->id : null
        ];

        $chapter->classe = [
            'id' => $chapter->classe,
            'options' => [
                'id' => Option::where('classe_id',$chapter->classe)->first()->id
            ]
        ];

        $chapter->teacher = $teacher->id;
        
        $response = $this->actingAs($teacher->user)
            ->post(route('chapters.store'),$chapter->toArray());

        return  [
            "chapter" => $chapter,
            "teacher" => $teacher,
            "response" => $response
        ];
    }

    protected function createExerciseForChapter(){
        $result = $this->createChapter();
        $response = $this->actingAs($result['teacher']->user)->post(
            route('chapters.exercises.store',["chapter"=>Chapter::first()->id]),
            \factory(Exercise::class)->make()->toArray()
        );
        $result['exercise'] = Exercise::first();
        return $result;
    }
}
