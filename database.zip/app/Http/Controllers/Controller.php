<?php

namespace App\Http\Controllers;

use App\Classe;
use App\Category;
use App\Exceptions\BadRequestException;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected function extractExerciseFields(Request $request){
        return array_merge(
            $request->only(['active']),
            ['type_id' =>  $request->get('type')]
        );
    }

    private function extractMatiere($request){
        $fields = [];
        if($request->has('matiere')){
            $matiere = $request->get('matiere');
            if(!isset($matiere['id'])){
                throw new BadRequestException("Matière mal formattée");
            }
            $fields['matiere_id'] = $matiere['id'];            
            $fields['specialite_id'] = isset($matiere['specialite']) ? $matiere['specialite'] : null;
        }
        return $fields;
    }

    private function extractClasse($request){
        $fields = [];
        if($request->has('classe')){
            $classe = $request->get('classe');
            if(!isset($classe['id'])){
                throw new BadRequestException("Classe mal formattée");
            }
            $fields['classe_id'] = $classe['id'];            
            $fields['options'] = isset($classe['options']) ? $classe['options'] : null;
        }
        return $fields;
    }

    private function extractTeacher($request){
        if($request->has('teacher')){
            return ['teacher_id' => $request->get('teacher')];
        }
        return [];
    }

    protected function extractEnseignementFields(Request $request){
        return array_merge(
            $this->extractMatiere($request),
            $this->extractClasse($request),
            $this->extractTeacher($request)
        );
    }

    protected function extractBookFields(Request $request){

        $fields = [];

        if($request->has('classes')){
            $fields['classes'] = collect($request->get('classes'))->map(function($classe){
                return Classe::findOrFail($classe['id'])->id;
            });
        }
        if($request->has('categories')){
            $fields['categories'] = collect($request->get('categories'))->map(function($classe){
                return Category::findOrFail($classe['id'])->id;
            });
        }
    
        return array_merge( 
            $this->extractMatiere($request), 
            $fields, 
            $this->extractTeacher($request)
        );
    }


    /**
     * 
     */
    protected function createdResponse($data,$message=null){
        $json = [
            "data" => $data
        ];
        if($message){
            $json['message'] = $message;
        }
        return response()->json($json,Response::HTTP_CREATED);
    }

    /**
     * 
     */
    protected function deletedResponse(){
        return response()->json([],Response::HTTP_NO_CONTENT);
    }

    /**
     * 
     */
    protected function conflictResponse($message=null){
        return response()->json([
            "message" => $message
        ],Response::HTTP_CONFLICT);
    }

    protected function inactiveResponse($message=null){
        return response()->json([
            "message" => "Cette résource n'est pas encore activée !"
        ],Response::HTTP_CONFLICT);
    }
}
