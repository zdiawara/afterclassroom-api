<?php

namespace App\Http\Controllers\Api;

use App\Notion;
use App\Exercise;
use App\Http\Controllers\Controller;
use App\Http\Resources\ExerciseResource;
use App\Http\Requests\ExerciseNotionRequest;


class ExerciseNotionController extends Controller
{
   

    public function __construct()
    {
        $this->middleware('auth:api');
        $this->middleware('role:teacher');

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ExerciseNotionRequest $request, Exercise $exercise)
    {
        $exercisable = $exercise->exercisable;

        $notions = [];

        foreach ($request->get('notions') as $key => $notion) {
            $aNotion = null;
            if(is_integer($notion['value'])){
                $aNotion = Notion::findOrFail($notion['value']);
            }else{
                $aNotion = Notion::create([
                    'title' => $notion['value'],
                    'teacher_id' => $exercisable->teacher->id,
                    'matiere_id' => $exercisable->matiere->id
                ]);
            }
            $notions[$aNotion->id] = ['type' => $notion['type']];
        }
        $exercise->notions()->attach($notions);
        $exercise->load('notions');
        
        return $this->createdResponse(new ExerciseResource($exercise));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
    }
}
