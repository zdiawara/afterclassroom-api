<?php

namespace App\Http\Controllers\Api;

use App\Chapter;
use App\Matiere;
use App\Exercise;
use App\Enseignement;
use App\Http\Controllers\Controller;
use App\Http\Requests\ChapterRequest;
use App\Http\Requests\ExerciseRequest;
use App\Http\Actions\Option\SyncOption;
use App\Http\Resources\ChapterResource;
use App\Http\Resources\ContentResource;
use App\Http\Resources\ExerciseResource;
use App\Http\Resources\ChapterCollection;
use App\Http\Actions\Content\ManageContent;
use Symfony\Component\HttpFoundation\Request;
use App\Http\Actions\Checker\EnseignementChecker;

class ChapterController extends Controller
{
    private $enseignementChecker;

    private $teacherMatiereChecker;

    public function __construct(EnseignementChecker $enseignementChecker,TeacherMatiereChecker $teacherMatiereChecker)
    {
        $this->middleware(['auth:api']);
        $this->middleware('role:teacher',['except' => ['index','show','showContent']]);
        $this->enseignementChecker = $enseignementChecker;
        $this->teacherMatiereChecker = $teacherMatiereChecker;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, Queries $queries)
    {
        //
        $teacher = $request->get('teacher');

        $query = Chapter::whereHas('teacher.user',function($q) use ($teacher){
            $q->where('username',$teacher);
        });

        $result = $queries->buildQuery($query,$request);

        return new ChapterCollection($result['query']->paginate(9,['*'], 'page', $result['page']));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param \App\Http\Requests\ChapterRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ChapterRequest $request, SyncOption $syncOption, ManageContent $manageContent)
    {
        //
        $fields = $this->extractEnseignementFields($request);
        
        $chapter = new Chapter(array_merge(
            $request->only(['title','resume','active']),
            collect($fields)->except('options')->all()
        ));
        
        $this->enseignementChecker->canCreate($chapter);

        $this->teacherMatiereChecker->canEdit($chapter->teacher,$chapter->matiere);
        
        $chapter->save();

        $syncOption->execute($chapter,$fields);

        $manageContent->create($chapter);
        
        return $this->createdResponse(new ChapterResource($chapter));
        
    }

    /**
     * 
     */
    public function storeExercise(ExerciseRequest $request, Chapter $chapter,  CreateExercise $createExercise)
    {
                
        $exercise = $createExercise->execute(new Exercise($this->extractExerciseFields($request)), $chapter);
        
        return $this->createdResponse(new ExerciseResource($exercise));
        
    }

    /**
     * 
     */
    public function showExercises(Chapter $chapter)
    {
        //dd($chapter->exercises()->with('notions')->get());
        $exercises = $chapter->exercises()->with(['type'])->get();
        return \response()->json([
            'teacher' => 'Test',
            //'data' => ExerciseResource::collection($exercises)
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Chapter  $chapter
     * @return \Illuminate\Http\Response
     */
    public function show(Chapter $chapter)
    {
        if(!$this->userChecker->canReadInactive($chapter->teacher->user->username)){
            return $this->inactiveResponse();
        }
        //
        $this->loadDependences($chapter);

        return new ChapterResource($chapter);
    }

    /**
     * Affiche le contenu du chapitre
     */
    public function showContent(Chapter $chapter){
        return new ContentResource($chapter->content);
    }

    private function loadDependences(Chapter $chapter){
        $chapter->load(['matiere','specialite','classe','options']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Chapter  $chapter
     * @return \Illuminate\Http\Response
     */
    public function update(ChapterRequest $request, Chapter $chapter, SyncOption $syncOption)
    {
        
        // Verifie que l'ut connecté peut créer modifier le chapitre
        $this->enseignementChecker->canUpdate($chapter);

        $fields = array_merge(
            $request->only(['title','resume','active']),
            $this->extractEnseignementFields($request)
        );

        // Recupère la matiere pour verifier que le prof peut l'enseigner
        $matiere = isset($fields['matiere_id']) ? Matiere::find($fields['matiere_id']) : $chapter->matiere;

        // Verifier que le chapitre peut être créer pour l'enseignant
        $this->teacherMatiereChecker->canEdit($chapter->teacher,$matiere);
                
        $chapter->update(collect($fields)->except('options')->all());
        
        // Active ou desactive le contenu
        if(isset($fields['active'])){
            $chapter->content->update(['active' => $fields['active'] ]);
        }

        // Sync les options
        $syncOption->execute($chapter,$fields);

        $this->loadDependences($chapter);
        
        return $this->createdResponse(new ChapterResource($chapter));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Chapter  $chapter
     * @return \Illuminate\Http\Response
     */
    public function destroy(Chapter $chapter)
    {
        //
    }
}
