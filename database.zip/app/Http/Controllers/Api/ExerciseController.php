<?php

namespace App\Http\Controllers\Api;

use App\Chapter;
use App\Exercise;
use App\Http\Actions\Queries;
use App\Http\Controllers\Controller;
use App\Http\Requests\ExerciseRequest;
use App\Http\Resources\ContentResource;
use App\Http\Resources\ExerciseResource;
use App\Http\Resources\ChapterCollection;
use App\Http\Actions\Exercise\CreateExercise;
use App\Http\Requests\ChapterExerciseRequest;
use Symfony\Component\HttpFoundation\Request;
use App\Http\Actions\Checker\EnseignementChecker;
use App\Http\Actions\Checker\TeacherMatiereChecker;

class ExerciseController extends Controller
{
    private $enseignementChecker;

    private $teacherMatiereChecker;

    public function __construct(EnseignementChecker $enseignementChecker,TeacherMatiereChecker $teacherMatiereChecker)
    {
        $this->middleware(['auth:api']);
        $this->enseignementChecker = $enseignementChecker;
        $this->teacherMatiereChecker = $teacherMatiereChecker;
    }

        /**
     * 
     */
    public function store(ChapterExerciseRequest $request, CreateExercise $createExercise)
    {
        $fields = $this->extractEnseignementFields($request);
        
        $chapter = null;
        if(is_integer($request->get('chapter'))){
            $chapter = Chapter::findOrFail($request->get('chapter'));
        }else{
            $chapter = new Chapter(array_merge(['title' => $request->get('chapter'),'active' => 1],
                collect($fields)->except('options')->all()
            ));
        }

        $exercise = $createExercise->execute(new Exercise($this->extractExerciseFields($request)), $chapter);
        
        return $this->createdResponse(new ExerciseResource($exercise));
        
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, Queries $queries)
    {
        //
        $teacher = $request->get('teacher');

        $query = Chapter::whereHas('teacher.user',function($q) use ($teacher){
            $q->where('username',$teacher);
        });

        $result = $queries->buildQuery($query,$request);

        //return new ChapterCollection($result['query']->withCount('exercises')->get());

    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Exercise  $exercise
     * @return \Illuminate\Http\Response
     */
    public function show(Exercise $exercise)
    {
        $this->enseignementChecker->checkReadInactive($exercise,$exercise->exercisable->teacher);
        //
        $exercise->load(['type','content','solution.content','notions']);

        return new ExerciseResource($exercise);
    }

    /**
     * 
     */
    public function update(ExerciseRequest $request, Exercise $exercise){

        $enseignement = $exercise->exercisable;

        $this->enseignementChecker->canUpdate($enseignement);

        $fields = $request->only(['active','notion','prerequis']);
        
        if($request->has('type')){
            $fields['type_id'] = $request->get('type');
        }

        if(isset($fields['active'])){
            $this->teacherMatiereChecker->canTeach($enseignement->teacher, $enseignement->matiere);
        }else{
            $this->teacherMatiereChecker->canEdit($enseignement->teacher, $enseignement->matiere );
        }

        $exercise->update($fields);

        if(isset($fields['active'])){
            $exercise->content->update(['active' => $fields['active'] ]);
            $exercise->solution->content->update(['active' => $fields['active'] ]);
        }

        $exercise->load('type');

        return $this->createdResponse(new ExerciseResource($exercise));
    }

     /**
     * Display the specified resource.
     *
     * @param  \App\Exercise  $exercise
     * @return \Illuminate\Http\Response
     */
    public function showEnonce(Exercise $exercise)
    {
        //
        $this->enseignementChecker->checkReadInactive($exercise->content,$exercise->exercisable->teacher);
        return new ContentResource($exercise->content);
    }

        /**
     * Récupère la correction d'un exercice
     */
    public function showSolution(Exercise $exercise){
        $this->enseignementChecker->checkReadInactive($exercise->solution->content,$exercise->exercisable->teacher);
        return new ContentResource($exercise->solution->content);
    }

    public function destroy()
    {
        
    }
}
