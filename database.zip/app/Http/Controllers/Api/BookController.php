<?php

namespace App\Http\Controllers\Api;

use App\Book;
use App\Matiere;
use App\Http\Actions\Queries;
use App\Http\Requests\BookRequest;
use App\Http\Controllers\Controller;
use App\Http\Resources\BookResource;
use App\Http\Actions\File\UploadFile;
use App\Http\Resources\BookCollection;
use App\Http\Actions\Sync;
use App\Http\Resources\ContentResource;
use App\Http\Actions\Content\ManageContent;
use Symfony\Component\HttpFoundation\Request;
use App\Http\Actions\Checker\EnseignementChecker;
use App\Http\Actions\Checker\TeacherMatiereChecker;

class BookController extends Controller
{
    private $enseignementChecker;

    private $teacherMatiereChecker;

    private $uploadFile;

    public function __construct(UploadFile $uploadFile, EnseignementChecker $enseignementChecker,TeacherMatiereChecker $teacherMatiereChecker)
    {
        $this->middleware(['auth:api']);
        $this->middleware('role:teacher',['except' => ['index','show']]);
        $this->enseignementChecker = $enseignementChecker;
        $this->teacherMatiereChecker = $teacherMatiereChecker;
        $this->uploadFile = $uploadFile;
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, Queries $queries)
    {
        //
        $teacher = $request->get('teacher');

        $query = Book::whereHas('teacher.user',function($q) use ($teacher){
            $q->where('username',$teacher);
        });

        $result = $queries->bookQuery($query,$request);

        return new BookCollection($result['query']->paginate(9,['*'], 'page', $result['page']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(BookRequest $request, Sync $sync, ManageContent $manageContent)
    {
        //
        $fields = $this->extractBookFields($request);

        $book = new Book(array_merge(
            $request->only(['title','resume','active','price']),
            collect($fields)->except(['classes','categories'])->all()
        ));

        $this->enseignementChecker->canCreate($book);
        $this->teacherMatiereChecker->canEdit($book->teacher,$book->matiere);
        
        if($request->has('cover')){
            $book->cover = $this->uploadFile->image($request->file('cover') );
        }else{
            $book->cover = 'cover.png';
        }
                
        $book->save();

        $sync->syncClasses($book,$fields);
        $sync->syncCategories($book,$fields);

        $manageContent->create($book);
        
        return $this->createdResponse(new BookResource($book));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Book $book)
    {
        //
        $this->loadDependences($book);
        return new BookResource($book);
    }

    private function loadDependences(Book $book){
        $book->load(['matiere','specialite','teacher','categories','classes']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(BookRequest $request, Book $book, Sync $sync)
    {
        // Verifie que l'ut connecté peut créer modifier le livre
        $this->enseignementChecker->canUpdate($book);

        $fields = array_merge(
            $request->only(['title','resume','active','price']),
            $this->extractBookFields($request)
        );

        // Recupère la matiere pour verifier que le prof peut l'enseigner
        $matiere = isset($fields['matiere_id']) ? Matiere::find($fields['matiere_id']) : $book->matiere;
        
        if(isset($fields['active'])){
            $this->teacherMatiereChecker->canTeach($book->teacher,$matiere);
        }else{
            $this->teacherMatiereChecker->canEdit($book->teacher,$matiere);
        }

        $book->update(collect($fields)->except(['classes','categories'])->all()); 

        // Active ou desactive le contenu
        if(isset($fields['active'])){
            $book->content->update(['active' => $fields['active'] ]);
        }

        $sync->syncClasses($book,$fields);
        $sync->syncCategories($book,$fields);

        $this->loadDependences($book);
        
        return $this->createdResponse(new BookResource($book));
    }

    /**
     * Affiche le contenu du livre
     */
    public function showContent(Book $book){
        return new ContentResource($book->content);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateCover(Request $request, Book $book)
    {
        
        if($request->file('cover')){
            $cover = $this->uploadFile->image($request->file('cover') );
            if(isset($cover)){
                $book->update(['cover' => $cover]);
            }
        }
        
        return $this->createdResponse(new BookResource($book));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
