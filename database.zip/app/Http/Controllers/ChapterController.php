<?php

namespace App\Http\Controllers;

use App\Chapter;
use App\Matiere;
use App\Exercise;
use App\Http\Actions\Queries;
use App\Http\Controllers\Controller;
use App\Http\Requests\ChapterRequest;
use App\Http\Requests\ExerciseRequest;
use App\Http\Resources\ClasseResource;
use App\Http\Actions\Option\SyncOption;
use App\Http\Resources\ChapterResource;
use App\Http\Resources\ContentResource;
use App\Http\Resources\MatiereResource;
use App\Http\Resources\TeacherResource;
use App\Http\Resources\ExerciseResource;
use App\Http\Actions\Checker\UserChecker;
use App\Http\Resources\ChapterCollection;
use App\Http\Actions\Content\ManageContent;
use App\Http\Actions\Exercise\CreateExercise;
use Symfony\Component\HttpFoundation\Request;
use App\Http\Actions\Checker\EnseignementChecker;
use App\Http\Actions\Checker\TeacherMatiereChecker;

class ChapterController extends Controller
{
    private $enseignementChecker;

    private $teacherMatiereChecker;

    private $userChecker;

    public function __construct(UserChecker $userChecker, EnseignementChecker $enseignementChecker,TeacherMatiereChecker $teacherMatiereChecker)
    {
        $this->middleware(['auth:api']);
        $this->middleware('role:teacher',['only' => ['store','update','storeExercise']]);
        $this->enseignementChecker = $enseignementChecker;
        $this->teacherMatiereChecker = $teacherMatiereChecker;
        $this->userChecker = $userChecker;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, Queries $queries)
    {
        //
        $teacher = $request->get('teacher');
        $user = \auth()->userOrFail();

        $query = Chapter::whereHas('teacher.user',function($q) use ($teacher){
            $q->where('username',$teacher);
        })->with(['specialite']);

        $canReadInactive = $this->userChecker->canReadInactive($teacher);
        
        if($request->get('type')!='notion'){
            $query = $query->whereHas('content');
            if(!$canReadInactive){
                $query = $query->where('active',1);
            }
        }else{
            $query->withCount(['exercises' => function($query) use ($canReadInactive){
                if(!$canReadInactive){
                    $query->where('active',1);
                }
            }]);
        }
        
        $result = $queries->buildQuery($query,$request);

        return new ChapterCollection($result['query']->paginate(9,['*'], 'page', $result['page']));

    }


    /**
     * Store a newly created resource in storage.
     *
     * @param \App\Http\Requests\ChapterRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ChapterRequest $request, SyncOption $syncOption, ManageContent $manageContent)
    {
        //
        $fields = $this->extractEnseignementFields($request);
        
        $chapter = new Chapter(array_merge(
            $request->only(['title','resume','active']),
            collect($fields)->except('options')->all()
        ));
        
        $this->enseignementChecker->canCreate($chapter);

        $this->teacherMatiereChecker->canEdit($chapter->teacher,$chapter->matiere);
        
        $chapter->save();

        $syncOption->execute($chapter,$fields);

        $manageContent->create($chapter);
        
        return $this->createdResponse(new ChapterResource($chapter));
        
    }

    /**
     * 
     */
    public function storeExercise(ExerciseRequest $request, Chapter $chapter,  CreateExercise $createExercise)
    {
                
        $exercise = $createExercise->execute(new Exercise($this->extractExerciseFields($request)), $chapter);
        
        return $this->createdResponse(new ExerciseResource($exercise));
        
    }

    /**
     * 
     */
    public function showExercises(Chapter $chapter)
    {
        $query = $chapter->exercises()->with(['type','exercisable.teacher']);

        if(!$this->userChecker->canReadInactive($chapter->teacher->user->username)){
            $query = $query->where('active',1);
        }

        return response()->json([
            'teacher' => new TeacherResource($chapter->teacher),
            'matiere' => new MatiereResource($chapter->matiere),
            'classe' => new ClasseResource($chapter->classe),
            'data' => ExerciseResource::collection($query->get())
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Chapter  $chapter
     * @return \Illuminate\Http\Response
     */
    public function show(Chapter $chapter)
    {
        $this->enseignementChecker->checkReadInactive($chapter,$chapter->teacher);
        //
        $this->loadDependences($chapter);
        $chapter->load("teacher");

        return new ChapterResource($chapter);
    }

    /**
     * Affiche le contenu du chapitre
     */
    public function showContent(Chapter $chapter){
        $this->enseignementChecker->checkReadInactive($chapter->content,$chapter->teacher);
        return new ContentResource($chapter->content);
    }

    private function loadDependences(Chapter $chapter){
        $chapter->load(['matiere','specialite','classe','options']);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Chapter  $chapter
     * @return \Illuminate\Http\Response
     */
    public function update(ChapterRequest $request, Chapter $chapter, SyncOption $syncOption)
    {
        
        // Verifie que l'ut connecté peut créer modifier le chapitre
        $this->enseignementChecker->canUpdate($chapter);

        $fields = array_merge(
            $request->only(['title','resume','active']),
            $this->extractEnseignementFields($request)
        );

        // Recupère la matiere pour verifier que le prof peut l'enseigner
        $matiere = isset($fields['matiere_id']) ? Matiere::findOrFail($fields['matiere_id']) : $chapter->matiere;
                
        
        if(isset($fields['active'])){
            $this->teacherMatiereChecker->canTeach($chapter->teacher,$matiere);
        }else{
            $this->teacherMatiereChecker->canEdit($chapter->teacher,$matiere);
        }

        $chapter->update(collect($fields)->except('options')->all());

        if(isset($fields['active'])){
            $chapter->content->update(['active' => $fields['active'] ]);
        }

        // Sync les options
        $syncOption->execute($chapter,$fields);

        $this->loadDependences($chapter);
        
        return $this->createdResponse(new ChapterResource($chapter));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Chapter  $chapter
     * @return \Illuminate\Http\Response
     */
    public function destroy(Chapter $chapter)
    {
        //
    }
}
