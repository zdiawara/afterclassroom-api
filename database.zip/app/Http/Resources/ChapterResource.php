<?php

namespace App\Http\Resources;

use App\Http\Resources\EnseignementResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ChapterResource extends EnseignementResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $enseignement = parent::toArray($request);
        
        if($this->exercises_count){
            $enseignement['totalExercises'] = $this->exercises_count;
        }
        return array_merge($enseignement,[
            'id' => $this->id,
            'title' => $this->title,
            'resume' => $this->resume,
            'active' => $this->active,
        ]);
    }
}
