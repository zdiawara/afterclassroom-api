<?php

namespace App\Http\Resources;

use App\ExerciseNotion;
use App\Http\Resources\ContentResource;
use App\Http\Resources\ReferentielResource;
use App\Http\Resources\ExerciseNotionResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ExerciseResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        
        $exercise = [
            'id' => $this->id,
            'type' => new ReferentielResource($this->whenLoaded('type')),
            'enseignement' => [
                'id' => $this->exercisable->id,
                'title' => $this->exercisable->title,
            ],
            'notions' => ExerciseNotionResource::collection(
                ExerciseNotion::where('exercise_id',$this->id)->with(['notion'])->get()
            ),
            'active' => $this->active,
            'notion' => $this->notion,
            'prerequis' => $this->prerequis,
            'enonce' => new ContentResource($this->whenLoaded('content')),
            'updated' => date('d/m/Y', strtotime($this->updated_at)),
        ];
        $solution = $this->whenLoaded('solution');
        if($solution && isset($solution->content)){
            $exercise['solution'] = new ContentResource($solution->content);
        }
        return $exercise;
    }
}
