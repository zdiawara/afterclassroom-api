<?php

namespace App\Http\Resources;

use App\Enums\UserRole;
use App\MatiereTeacher;
use App\Http\Resources\UserResource;
use App\Http\Resources\MatiereTeacherResource;
use Illuminate\Http\Resources\Json\JsonResource;

class TeacherResource extends UserResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $user = parent::toArray($request);
        
        $user['role'] = UserRole::TEACHER;
        if($this->teacher_matieres){
            $user['matieres'] = MatiereTeacherResource::collection($this->teacher_matieres);
        }
        if($this->classes){
            $user['classes'] = ClasseResource::collection($this->classes);
        }
        if(isset($this->exercises_count)){
            $user['totalExercises'] = $this->exercises_count;
        }
        if(isset($this->chapters_count)){
            $user['totalChapters'] = $this->chapters_count;
        }
        if(isset($this->controles_count)){
            $user['totalControles'] = $this->controles_count;
        }
        if(isset($this->students_count)){
            $user['totalStudents'] = $this->students_count;
        }
        if(isset($this->collegeYear)){
            $user['collegeYear'] = new CollegeYearResource($this->collegeYear);
        }
        return $user;
    }
}
