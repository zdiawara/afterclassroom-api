<?php

namespace App\Http\Resources;

use App\Http\Resources\OptionResource;
use App\Http\Resources\SubjectResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ClasseResource extends JsonResource{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request){
        $classe = [
            'id' => $this->id,
            'name' => $this->name,
            'abreviation' => $this->abreviation,
            'code' => $this->code,
            'subjects' => SubjectResource::collection($this->whenLoaded('subjects')),
            'level' => new ReferentielResource($this->whenLoaded('level')),
            'options' => OptionResource::collection($this->whenLoaded('options')),
        ];

        if(isset($this->exercises_count)){
            $classe['exercises_count'] = $this->exercises_count;
        }

        if(isset($this->controles_count)){
            $classe['controles_count'] = $this->controles_count;
        }
        
        return $classe;
    }
}
