<?php

namespace App\Http\Resources;

use App\Http\Resources\SubjectResource;
use App\Http\Resources\ReferentielResource;
use App\Http\Resources\EnseignementResource;
use Illuminate\Http\Resources\Json\JsonResource;

class ControleResource extends EnseignementResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $enseignement = parent::toArray($request);
        
        if(isset($this->exercises_count)){
            $enseignement['totalExercises'] = $this->exercises_count;
        }
        return array_merge($enseignement,[
            'id' => $this->id,
            'year' => $this->year,
            'type' => new ReferentielResource($this->whenLoaded('type')),
            'subject' => new SubjectResource($this->whenLoaded('subject')),
            'teacher' => new UserResource($this->whenLoaded('teacher')),
            'active' => $this->active,
        ]);
    }
}
