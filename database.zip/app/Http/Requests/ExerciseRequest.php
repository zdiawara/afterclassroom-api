<?php

namespace App\Http\Requests;

use App\Http\Requests\CustumRequest;
use App\Http\Requests\EnseignementRules;
use Illuminate\Foundation\Http\FormRequest;

class ExerciseRequest extends CustumRequest
{
    
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'type' => 'required'
        ];
        return $this->makeRules(array_merge(
            collect(EnseignementRules::getRules())->only('active')->all(),
            $rules
        ));
    }
}
