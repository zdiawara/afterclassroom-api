<?php

namespace App\Http\Requests;

use App\Http\Requests\CustumRequest;
use App\Http\Requests\EnseignementRules;

class ExerciseNotionRequest extends CustumRequest
{
    
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            
            'notions.*.value' => 'required',
            'notions.*.type'=> 'boolean'
        ];
        return $rules;
    }
}
