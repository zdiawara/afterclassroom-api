<?php

namespace App\Http\Requests;

class EnseignementRules {
    
    public static function getRules(){
        return [
            'classe' => 'required',
            'classe.id' => 'required',
            'matiere' => 'required',
            'matiere.id' => 'required',
            'teacher' => 'required'
        ];
    }
}
