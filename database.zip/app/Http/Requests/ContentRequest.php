<?php

namespace App\Http\Requests;

use App\Http\Requests\CustumRequest;

class ContentRequest extends CustumRequest
{

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {        
        $rules = [
            "data" => "required",
            'active' => 'required|boolean',
        ];
        return $this->makeRules($rules);
    }
}
