<?php

namespace App\Http\Actions;

class Queries{

    
    public function whereHas($query,$relation,$code){
        return $query->whereHas($relation,function($q) use ($code){
            $q->where('code',$code);
        });
    }

    public function buildCommonQuery($query,$request){
        $matiere = $request->get('matiere');
        $specialite = $request->get('specialite');
        $page = $request->get('page',1);

        $newQuery = $query;

        if(isset($matiere)){
            $newQuery = $this->whereHas($query,'matiere',$matiere);
        }
        if(isset($specialite)){
            $newQuery = $newQuery->where('specialite_id',$specialite);
        }

        return [
            'query' => $newQuery,
            'page' => $page
        ];
    }

    public function buildQuery($query,$request){
        
        $classe = $request->get('classe');
        
        $result = $this->buildCommonQuery($query,$request);

        if(isset($classe)){
            $result['query'] = $this->whereHas($result['query'],'classe',$classe);
        }

        return $result;
    }

    public function bookQuery($query,$request){
        
        $classe = $request->get('classe');
        
        $result = $this->buildCommonQuery($query,$request);

        if(isset($classe)){
            $result['query'] = $this->whereHas($result['query'],'classes',$classe);
        }
        
        return $result;
    }

}