<?php

namespace App;

use Exception;
use App\Classe;
use App\Option;
use App\Category;
use App\Referentiel;
use App\Enseignement;
use App\Constants\TypeReferentiel;
use Illuminate\Database\Eloquent\Model;

class Book extends Enseignement
{
    //
    protected $guarded = [];

    
    public function content(){
        return $this->morphOne('App\Content','contentable');
    }

    public function classes(){
        return $this->belongsToMany(Classe::class);
    }

    public function options(){
        return $this->belongsToMany(Option::class);
    }
    
    public function categories(){
        return $this->belongsToMany(Category::class);
    }


    public function setCategoryIdAttribute($code){
        if(!is_null($code)){
            $ref = Referentiel::where('code',$code)->where('type',TypeReferentiel::CATEGORY)->first();
            if(\is_null($ref)){
                // Exception
                throw new Exception("Referentiel incorrect", 1);
            }
            $this->attributes['category_id'] = $ref->id;
        }
    }
}
