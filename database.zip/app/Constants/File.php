<?php
namespace App\Constants;

class File{
    
    const PATH_JUSTIFICATIFS = "justificatifs";
    const PATH_IMAGES = "images";
    const PATH_COVERS = "images/covers";

    const DISK_PUBLIC = "public";
}