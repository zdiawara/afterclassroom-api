<?php
namespace App\Constants;

class Message{
    
}