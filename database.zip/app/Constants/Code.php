<?php
namespace App\Constants;

class Code{
    const ENONCE = "enonce";
    const SOLUTION = "solution";    
}