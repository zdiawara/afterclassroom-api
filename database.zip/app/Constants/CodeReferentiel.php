<?php
namespace App\Constants;

class CodeReferentiel{
    
    // Code etat
    const VALIDATING = "validating";
    const VALIDATED = "validated";
    const REJECTED = "rejected";

    const EXERCISE = "exercise";
    const PROBLEM = "problem";

    const DEVOIR = "devoir";
    const EXAMEN = "examen";
    const COMPOSITION = "composition";

    const BAC = "bac";
    const BEPC = "bepc";
    const SUJET_TYPE_BEPC = "sujet_type_bepc";
    const SUJET_TYPE_BAC = "sujet_type_bac";

    const ROMAN = "roman";
    const LIVRE = "livre";

    const IN_PROGRESS = "in_progress";
    const FINISHED = "finished";
    
    const HOMME = "homme";
    const FEMME = "femme";

    const COLLEGE = "college";
    const LYCEE = "lycee";
}