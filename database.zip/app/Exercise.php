<?php

namespace App;

use App\Notion;
use App\Solution;
use App\Referentiel;
use Illuminate\Database\Eloquent\Model;

class Exercise extends Model
{
    protected $guarded = [];
    
    //
    public function type(){
        return $this->belongsTo(Referentiel::class);
    }

    public function exercisable(){
        return $this->morphTo();
    }

    // les notions 
    public function notions(){
        return $this->belongsToMany(Notion::class);
    }

    // Solution de l'exercice
    public function solution(){
        return $this->hasOne(Solution::class);
    }

    // Enoncé de l'exercice
    public function content(){
        return $this->morphOne('App\Content','contentable');
    }

}
