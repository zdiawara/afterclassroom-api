<?php

namespace App;

use App\Classe;
use App\Option;
use App\Teacher;
use App\Exceptions\PrivilegeException;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    protected $guarded = [];
    
    // Relation avec User
    public function user(){
        return $this->morphOne('App\User','userable');
    }

    public function classe(){
        return $this->belongsTo(Classe::class);
    }

    public function option(){
        return $this->belongsTo(Option::class);
    }

    public function teachers(){
        return $this->belongsToMany(Teacher::class)->withPivot('matiere_id');
    }

    public function setClasseIdAttribute($id){
        if(!is_null($id)){
            $this->attributes['classe_id'] = Classe::findOrFail($id)->id;
            $this->attributes['option_id'] = null;
        }
    }

    public function setOptionIdAttribute($id){
        $this->attributes['option_id'] = null;
        if(is_null($id)){
            return;
        }
        $option = Option::where('classe_id',$this->classe_id)->where('id',$id)->first();
        
        if(!isset($option)){
            throw new PrivilegeException("Impossible d'associer cette option et la classe !");
        }
        $this->attributes['option_id'] = $option->id;
    }
}
