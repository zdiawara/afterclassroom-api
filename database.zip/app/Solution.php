<?php

namespace App;

use App\Controle;
use App\Exercise;
use Illuminate\Database\Eloquent\Model;

class Solution extends Model{
    
    public function exercise(){
        return $this->belongsTo(Exercise::class);
    }
    public function controle(){
        return $this->belongsTo(Controle::class);
    }
    public function content(){
        return $this->morphOne('App\Content','contentable');
    }
}
