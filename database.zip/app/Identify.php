<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Identify extends Model
{
    //
    protected $guarded = [];
}
