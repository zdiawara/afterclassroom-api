<?php

namespace App;

use App\Matiere;
use App\Teacher;
use Illuminate\Database\Eloquent\Model;

class Notion extends Model
{
    //
    protected $guarded = [];

    public function matiere(){
        return $this->belongsTo(Matiere::class);
    }

    public function teacher(){
        return $this->belongsTo(Teacher::class);
    }
}
