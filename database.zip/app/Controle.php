<?php

namespace App;

use Exception;
use App\Subject;
use App\Solution;
use App\Referentiel;
use App\Constants\TypeReferentiel;
use App\Exceptions\BadRequestException;
use Illuminate\Database\Eloquent\Model;

class Controle extends Enseignement
{
    //

    public function exercises(){
        return $this->morphMany('App\Exercise','exercisable');
    }
    

    public function type(){
        return $this->belongsTo(Referentiel::class);
    }

    public function subject(){
        return $this->belongsTo(Subject::class);
    }


    public function setTypeIdAttribute($code){
        if(!is_null($code)){
            $ref = Referentiel::where('code',$code)->where('type',TypeReferentiel::CONTROLE)->first();
            if(\is_null($ref)){
                throw new BadRequestException("Referentiel incorrect");
            }
            $this->attributes['type_id'] = $ref->id;
        }
    }

    public function setSubjectIdAttribute($code){
        if(!is_null($code)){
            $this->attributes['subject_id'] = Subject::where('code',$code)->firstOrFail()->id;
        }
    }

    // Solution du controle
    public function solution(){
        return $this->hasOne(Solution::class);
    }

    // Enoncé du controle
    public function content(){
        return $this->morphOne('App\Content','contentable');
    }
}
