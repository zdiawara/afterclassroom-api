<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BookReferentiel extends Model
{
    //
    protected $table = 'book_referentiel';

}
