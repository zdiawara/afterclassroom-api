<?php
namespace App\Enums;

class UserRole{
    const TEACHER = 'teacher';
    const ADMIN = 'admin';
    const STUDENT = 'student';
}