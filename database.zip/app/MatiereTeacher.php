<?php

namespace App;

use Exception;
use App\Matiere;
use App\Teacher;
use App\Referentiel;
use App\Constants\CodeReferentiel;
use App\Constants\TypeReferentiel;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MatiereTeacher extends Model
{
    use SoftDeletes;
    
    protected $table = 'matiere_teacher';
    
    protected $fillable = array('teacher_id','matiere_id','justificatif','etat_id');

    protected $dates = ['deleted_at'];

    public function matiere(){
        return $this->belongsTo(Matiere::class);
    }

    public function teacher(){
        return $this->belongsTo(Teacher::class);
    }

    public function etat(){
        return $this->belongsTo(Referentiel::class);
    }

    public function setMatiereIdAttribute($id){
        if(!is_null($id)){
            $this->attributes['matiere_id'] = Matiere::findOrFail($id)->id;
        }
    }

    public function setEtatIdAttribute($id){
        if(!is_null($id)){
            $etat = Referentiel::findOrFail($id);
            if($etat->type != TypeReferentiel::ETAT){
                // Exception
                throw new Exception("Referentiel incorrect", 1);
            }
            $this->attributes['etat_id'] = $etat->id;
        }
    }
}
