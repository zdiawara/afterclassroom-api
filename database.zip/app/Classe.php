<?php

namespace App;

use App\Option;
use App\Subject;
use App\Referentiel;
use Illuminate\Database\Eloquent\Model;

class Classe extends Model
{
    //
    public function options(){
        return $this->hasMany(Option::class);
    }
    public function subjects(){
        return $this->hasMany(Subject::class);
    }

    public function level(){
        return $this->belongsTo(Referentiel::class);
    }
}
