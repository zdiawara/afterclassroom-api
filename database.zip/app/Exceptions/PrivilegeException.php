<?php

namespace App\Exceptions;

use Exception;

class PrivilegeException extends Exception
{
    //
}
