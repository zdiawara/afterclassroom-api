<?php

namespace App;

use App\Classe;
use App\Matiere;
use App\Teacher;
use App\Specialite;
use App\Exceptions\PrivilegeException;
use Illuminate\Database\Eloquent\Model;

class Chapter extends Model
{
    protected $guarded = [];

    public function matiere(){
        return $this->belongsTo(Matiere::class);
    }

    public function classe(){
        return $this->belongsTo(Classe::class);
    }

    public function specialite(){
        return $this->belongsTo(Specialite::class);
    }

    public function teacher(){
        return $this->belongsTo(Teacher::class);
    }

    public function options(){
        return $this->morphToMany('App\Option', 'enseignementable');
    }

    public function content(){
        return $this->morphOne('App\Content','contentable');
    }

    public function exercises(){
        return $this->morphMany('App\Exercise','exercisable');
    }

    public function setMatiereIdAttribute($id){
        if(!is_null($id)){
            $this->attributes['matiere_id'] = Matiere::findOrFail($id)->id;
        }
    }

    public function setClasseIdAttribute($id){
        if(!is_null($id)){
            $this->attributes['classe_id'] = Classe::findOrFail($id)->id;
        }
    }

    public function setSpecialiteIdAttribute($id){
        if(!is_null($id)){
            $specialite = Specialite::where('matiere_id',$this->matiere_id)->where('id',$id)->first();
            
            if(isset($specialite)){
                $this->attributes['specialite_id'] = $specialite->id;
            }else{
                throw new PrivilegeException("Impossible d'associer cette spécialité et la matière !");
            }
            
        }else{
            $this->attributes['specialite_id'] = null;
        }
    }

    public function setTeacherIdAttribute($id){
        if(!is_null($id)){
            $this->attributes['teacher_id'] = Teacher::findOrFail($id)->id;
        }
    }

}
