<?php

namespace App;

use App\Notion;
use Illuminate\Database\Eloquent\Model;

class ExerciseNotion extends Model
{
    //
    protected $table = 'exercise_notion';
    
    public function notion(){
        return $this->belongsTo(Notion::class);
    }
}
