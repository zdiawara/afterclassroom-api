<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group([
    'middleware' => 'api',
], function ($router) {
    Route::post('login', 'Api\AuthController@login');
    Route::post('logout', 'Api\AuthController@logout');
    Route::post('refresh', 'Api\AuthController@refresh');
    Route::post('me', 'Api\AuthController@me');
});

Route::apiResource('referentiels' , "Api\ReferentielController");

Route::apiResource('teachers' , "Api\TeacherController");
Route::group(['prefix' => 'teachers'], function ($router) {
    Route::get('/{teacher}/resume', 'Api\TeacherController@resume')->name('teachers.resume');
    Route::post('/{teacher}/avatar', 'Api\TeacherController@updateAvatar')->name('teachers.updateAvatar');
});

Route::apiResource('teachers.matieres' , "Api\TeacherMatiereController");

// Student
Route::apiResource('students' , "Api\StudentController");
Route::apiResource('students.teachers' , "Api\StudentTeacherController");

// Book
Route::group(['prefix' => 'books'], function ($router) {
    Route::post('/{book}/cover', 'Api\BookController@updateCover')->name('books.updateCover');
    Route::get('/{book}/content', 'Api\BookController@showContent')->name('books.content');
});
Route::apiResource('books' , "Api\BookController");
Route::apiResource('books.categories' , "Api\BookCategoryController");
Route::apiResource('categories' , "Api\CategoryController");

// Chapter
Route::group(['prefix' => 'notions'], function ($router) {
    Route::get('/{chapter}', 'Api\NotionController@show')->name('notions.show');
    Route::get('/', 'Api\NotionController@index')->name('notions.index');
});
// chapters exercises
Route::group(['prefix' => 'chapters'], function ($router) {
    Route::get('/{chapter}/content', 'ChapterController@showContent')->name('chapters.content');
    Route::post('/{chapter}/exercises', 'ChapterController@storeExercise')->name('chapters.exercises.store');
    Route::get('/{chapter}/exercises', 'ChapterController@showExercises')->name('chapters.exercises.index');
});
Route::apiResource('chapters' , "ChapterController");

// controles
Route::apiResource('controles' , "Api\ControleController");
// controles exercices
Route::group(['prefix' => 'controles'], function ($router) {
    Route::post('/{controle}/exercises', 'Api\ControleController@storeExercise')->name('controles.exercises.store');
    Route::get('/{controle}/exercises', 'Api\ControleController@showExercises')->name('controles.exercises.index');
    Route::get('/{controle}/solution', 'Api\ControleController@showSolution')->name('controles.solution');
    Route::get('/{controle}/enonce', 'Api\ControleController@showEnonce')->name('controles.enonce');
});

// Exercise
Route::group(['prefix' => 'exercises'], function ($router) {
    Route::get('/', 'Api\ExerciseController@index')->name('exercises.index');
    Route::post('/', 'Api\ExerciseController@store')->name('exercises.store');
    Route::get('/{exercise}', 'Api\ExerciseController@show')->name('exercises.show');
    Route::put('/{exercise}', 'Api\ExerciseController@update')->name('exercises.update');
    Route::get('/{exercise}/enonce', 'Api\ExerciseController@showEnonce')->name('exercises.showEnonce');
    Route::get('/{exercise}/solution', 'Api\ExerciseController@showSolution')->name('exercises.showSolution');
});

// Exercise notions
Route::apiResource('exercises.notions' , "Api\ExerciseNotionController");


// Content
Route::put('/contents/{content}', 'Api\ContentController@update')->name('contents.update');

/////
Route::apiResource('matieres' , "Api\MatiereController");
Route::apiResource('matieres.specialites' , "Api\SpecialiteController");
Route::apiResource('classes' , "Api\ClasseController");

Route::apiResource('files' , "Api\FileController");

Route::group(['prefix' => 'files'], function ($router) {
    Route::get('/{root}/{filename}', 'Api\FileController@show')->name('files.show');
});

Route::group(['prefix' => 'mails'], function ($router) {
    Route::post('/', 'Api\MailController@send')->name('mails.send');
});

