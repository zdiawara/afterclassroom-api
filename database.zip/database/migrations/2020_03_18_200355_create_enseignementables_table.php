<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEnseignementablesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('enseignementables', function (Blueprint $table) {
            $table->unsignedBigInteger('enseignementable_id');
            $table->unsignedBigInteger('option_id');
            $table->timestamps();
            
            $table->string('enseignementable_type'); 
            $table->foreign('option_id')->references('id')->on('options');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('enseignementables');
    }
}
