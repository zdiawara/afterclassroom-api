<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateExercisesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('exercises', function (Blueprint $table) {
            $table->id();
            $table->boolean('active');
            $table->string('notion',255)->nullable();
            $table->string('prerequis',255)->nullable();
            $table->unsignedBigInteger('type_id');
            $table->bigInteger('exercisable_id')->unsigned();
            $table->string('exercisable_type');   
            $table->timestamps();
            
            $table->foreign('type_id')->references('id')->on('referentiels');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('exercises');
    }
}
