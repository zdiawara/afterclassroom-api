<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateNotionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('notions', function (Blueprint $table) {
            $table->id();

            $table->string('title',100);
            $table->unsignedBigInteger('teacher_id');
            $table->unsignedBigInteger('matiere_id');
            $table->timestamps();
            //$table->softDeletes();

            $table->foreign('teacher_id')->references('id')->on('teachers');
            $table->foreign('matiere_id')->references('id')->on('matieres');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('notions');
    }
}
