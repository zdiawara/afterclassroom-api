<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Exercise;
use App\Referentiel;
use Faker\Generator as Faker;
use App\Constants\CodeReferentiel;
use App\Constants\TypeReferentiel;

$factory->define(Exercise::class, function (Faker $faker) {
    return [
        "type" => Referentiel::firstOrCreate([
            'code' => CodeReferentiel::EXERCISE,
            'type' => TypeReferentiel::EXERCISE
        ],[
            'name' => $faker->word
        ])->id,

        'active' => 0
    ];
});
