<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Book;
use App\Model;
use App\Classe;
use App\Option;
use App\Category;
use App\Specialite;
use App\Referentiel;
use Faker\Generator as Faker;
use Illuminate\Http\UploadedFile;
use App\Constants\CodeReferentiel;
use App\Constants\TypeReferentiel;

$factory->define(Book::class, function (Faker $faker) {
    return [
        'title'=>$faker->text(rand(20,50)),
        'resume'=>$faker->text(rand(150,255)),
        'active'=>rand(0,1),
        'price'=>$faker->randomNumber(3),
        "cover" => UploadedFile::fake()->image("cover.png")
    ];
});


$factory->afterMaking(Book::class, function ($book, $faker) {

    Category::firstOrCreate(['code' => CodeReferentiel::ROMAN ],[
        'name' => $faker->word
    ]);

    Category::firstOrCreate(['code' => CodeReferentiel::LIVRE ],[
        'name' => $faker->word
    ]);

    $classe = factory(Classe::class)->create();
    
    $specialite = factory(Specialite::class)->create();
    
    $book->classes = $classe->id;
    $book->matiere = $specialite->matiere->id;

    $option = factory(Option::class)->make();
    $option->classe_id = $classe->id;
    $option->save();    
});
