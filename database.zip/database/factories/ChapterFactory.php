<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Classe;
use App\Option;
use App\Chapter;
use App\Matiere;
use App\Specialite;
use App\Referentiel;
use Faker\Generator as Faker;

$factory->define(Chapter::class, function (Faker $faker) {
    return [
        'title'=>$faker->word,
        'resume'=>$faker->text(rand(150,255)),
        'active'=>rand(0,1),
    ];
});

$factory->afterMaking(Chapter::class, function ($chapter, $faker) {
    $classe = factory(Classe::class)->create();
    
    $specialite = factory(Specialite::class)->create();
    
    $chapter->classe = $classe->id;
    $chapter->matiere = $specialite->matiere->id;

    $option = factory(Option::class)->make();
    $option->classe_id = $classe->id;
    $option->save();    
});