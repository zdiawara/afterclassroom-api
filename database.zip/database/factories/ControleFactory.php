<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Classe;
use App\Subject;
use App\Controle;
use App\Specialite;
use App\Referentiel;
use Faker\Generator as Faker;
use App\Constants\CodeReferentiel;
use App\Constants\TypeReferentiel;

$factory->define(Controle::class, function (Faker $faker) {
    return [
        'year'=>$faker->year,
        'active'=>rand(0,1),
    ];
});

$factory->afterMaking(Controle::class, function ($controle, $faker) {
    $classe = factory(Classe::class)->create();
    $controle->classe = $classe->id;   
    $controle->type = Referentiel::firstOrCreate(['code' => CodeReferentiel::DEVOIR, 'type' => TypeReferentiel::CONTROLE],
    ['name' => $faker->word])->code;
    $specialite = factory(Specialite::class)->create();
    $controle->matiere = $specialite->matiere->id;
    
});
