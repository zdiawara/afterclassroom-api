<?php

use App\User;
use App\Admin;
use App\Classe;
use App\Option;
use App\Matiere;
use App\Student;
use App\Subject;
use App\Teacher;
use App\Category;
use App\Identify;
use App\Specialite;
use App\CollegeYear;
use App\Referentiel;
use Illuminate\Database\Seeder;
use App\Constants\CodeReferentiel;
use App\Constants\TypeReferentiel;
use App\Http\Actions\User\ManageIdentify;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        Identify::create([
            'tranche' => 10,
            "current" => 0
        ]);
        
        $this->createReferentiels();
        
        ////// Classes ////////
        $classes = $this->generateClasses();

        $this->createSubject("Sujet type Bepc",CodeReferentiel::SUJET_TYPE_BEPC,'troisieme');
        $this->createSubject("Bepc",CodeReferentiel::BEPC,'troisieme');
        $this->createSubject("Sujet type Bac",CodeReferentiel::SUJET_TYPE_BAC,"terminale");
        $this->createSubject("Bac",CodeReferentiel::BAC,'terminale');

        ////// Matiere ////
        $this->generateMatieres();

        $lycee = Referentiel::where('type',TypeReferentiel::LEVEL)
            ->where('code',CodeReferentiel::LYCEE)->first();
        
        $college = Referentiel::where('type',TypeReferentiel::LEVEL)
            ->where('code',CodeReferentiel::COLLEGE)->first();
        // Creation d'un teacher
        $this->createTeacher('Yamao','Lovie','lovie.yamao@test.com','lovie',['maths'],$lycee);
        $this->createTeacher('Joseph','Ibara','ibara.joseph@test.com','ibara',['pc'],$lycee);
        $this->createTeacher('Sebastian','Mampassi','mampassi.sebastian@test.com','mampassi',['svt'],$lycee);
        $this->createTeacher('Baobab','Sidibé','sidibe.baobab@test.com','sidibe',['francais'],$lycee);
        $this->createTeacher('Nafa','Traoré','traore.nafa@test.com','nafa',['hg'],$college);
        $this->createTeacher('Jean','Descartes','descartes.jean@test.com','descartes',['philosophie'],$college);
        $this->createTeacher('Moussa','Coulibaly','coulibaly.moussa@test.com','coulibaly',['anglais'],$college);

        $this->createStudent('Moussa','Ouattara','ouattara.moussa@test.com','moussa','terminale');
        $this->createStudent('Alassane','Traoré','traore.alassane@test.com','alassane','troisieme');
        $this->createStudent('Jean','Somé','some.jean@test.com','jean','sixieme');
        

    }

    private function createReferentiels(){

        $this->createReferentiel('Homme','homme', 'gender');
        $this->createReferentiel('Femme','femme', 'gender');

            ///// Niveau d'enseignement /////
        $secondaire =  $this->createReferentiel('Collège',CodeReferentiel::COLLEGE, TypeReferentiel::LEVEL);
        $secondaire =  $this->createReferentiel('Lycée',CodeReferentiel::LYCEE, TypeReferentiel::LEVEL);
                
        ////// categories de livres
        $this->createCategory('Annale','annale');
        $this->createCategory('Roman','roman');
        $this->createCategory('Livre','livre');
    
        ///// Ajout referentiel controle
        $this->createReferentiel('Devoir',CodeReferentiel::DEVOIR, TypeReferentiel::CONTROLE);
        $this->createReferentiel('Composition',CodeReferentiel::COMPOSITION, TypeReferentiel::CONTROLE);
        $this->createReferentiel('Examen',CodeReferentiel::EXAMEN, TypeReferentiel::CONTROLE);
    
        $this->createReferentiel("Application",'exercise', 'typeExercise');
        $this->createReferentiel('Synthèse','probleme', 'typeExercise');

        // Etat Justificatif
        $this->createReferentiel('Validé',CodeReferentiel::VALIDATED, TypeReferentiel::ETAT);
        $this->createReferentiel('En validation',CodeReferentiel::VALIDATING, TypeReferentiel::ETAT);
        $this->createReferentiel('Rejecté',CodeReferentiel::REJECTED, TypeReferentiel::ETAT);

        $ref = $this->createReferentiel('En cours',CodeReferentiel::IN_PROGRESS, TypeReferentiel::ETAT_COLLEGE_YEAR);
        $year = date('Y', strtotime(now()));
        CollegeYear::create([
            'name' => ($year-1).'-'.$year,
            'year' => $year,
            'etat_id' => $ref->id
        ]);
        $this->createReferentiel('Terminé',CodeReferentiel::FINISHED, TypeReferentiel::ETAT_COLLEGE_YEAR);

    }

    private function createReferentiel($name, $code, $type){
        return Referentiel::create(['name' => $name,'code' => $code, 'type' => $type ]);
    }

    private function createCategory($name, $code){
        return Category::create(['name' => $name,'code' => $code]);
    }

    private function generateClasses(){
      
        $college = Referentiel::where('code','college')->where('type','level')->first();
        Classe::create($this->generateClasse('Sixième','6°','sixieme',1,$college));
        Classe::create($this->generateClasse('Cinquième','5°','cinquieme',2,$college));
        Classe::create($this->generateClasse('Quatrième','4°','quatrieme',3,$college));
        Classe::create($this->generateClasse('Troisième','3°','troisieme',4,$college));
       
        $lycee = Referentiel::where('code','lycee')->where('type','level')->first();

        $seconde = Classe::create($this->generateClasse('Seconde','2nde','seconde',5,$lycee));
        $this->generateOption(['A','C','AC'],$seconde);
       
        $premiere = Classe::create($this->generateClasse('Première','1ère','premiere',6,$lycee));
        $this->generateOption(['A','D','C'],$premiere);
      
        $tle = Classe::create($this->generateClasse('Terminale','Tle','terminale',7,$lycee));
        $this->generateOption(['A','C','D'],$tle);

    }

     
    private function generateClasse($name,$abreviation,$code,$niveau,$level){
        return[
            'name'=>$name,
            'abreviation'=>$abreviation,
            'code'=>$code,
            'order'=>$niveau,
            'level_id'=>$level->id
        ];
    }


    
    private function generateMatieres(){
    
        $maths = $this->generateMatiere('Mathématiques','maths', 'Maths');

        $pc = $this->generateMatiere('Physique-Chimie','pc','PC');
        $this->generateSpecialite('Physique','physique',$pc);
        $this->generateSpecialite('Chimie','chimie',$pc);

        $svt = $this->generateMatiere('SVT','svt','SVT');
        
        $francais = $this->generateMatiere('Français','francais','Fr');

        $this->generateMatiere('Anglais','anglais','Ang');

        //$histoire = $this->generateMatiere('Histoire','histoire','Hist');

        $hg = $this->generateMatiere('Histoire-Géographie','hg','HG');
        $this->generateSpecialite('Géographie','geographie',$hg);
        $this->generateSpecialite('Histoire','histoire',$hg);
        
        $philosophie = $this->generateMatiere('Philosophie','philosophie','Phil');
        
    }

    public function generateSpecialite($name, $code, $matiere){
        $specialite = new Specialite();
        $specialite->name = $name;
        $specialite->code = $code;
        $specialite->matiere_id = $matiere->id;
        $specialite->save();
    
    }

    private function generateMatiere($name,$code,$abreviation){
        return Matiere::create([
            'name'=>$name,
            'code'=>$code,
            'abreviation'=>$abreviation
        ]);
    }

    private function generateOption($names=[],$classe){
        foreach ($names as $name) {
            $option = new Option();
            $option->name = $name;
            $option->classe_id = $classe->id;
            $option->save();
        }
    }

    private function createTeacher($firstname,$lastname, $email, $username, $matieres,$level){
        $teacher = new Teacher();
        $teacher->level_id = $level->id;
        $teacher->save();
        $user = new User([
            'firstname' => $firstname,
            'lastname' => $lastname,
            'username'=>(new ManageIdentify)->buildIdentify(),
            'email' => $email,
            'email_verified_at' => now(),
            'password' => bcrypt('secret'),
            'avatar' => 'avatar.png',
            'gender_id' => Referentiel::where("code", CodeReferentiel::HOMME)->where("type",TypeReferentiel::GENDER)->first()->id
        ]);
        $teacher->user()->save($user);

        $refEtat = Referentiel::where("code", CodeReferentiel::VALIDATED)->where("type",TypeReferentiel::ETAT)->first();
        
        collect($matieres)->each(function($code) use($teacher,$refEtat){
            $matiere = Matiere::where('code',$code)->first();
            $teacher->matieres()->attach($matiere->id,[
                'etat_id' => $refEtat->id,
                //'justificatif' => 'test.pdf'
            ]);
        });

    }

    private function createStudent($firstname,$lastname, $email, $username, $classe){
        $student = new Student();
        $student->classe_id = Classe::where('code',$classe)->first()->id;
        //$student->option_id = Option::where('classe_id',$student->classe_id)->first()->id;
        $student->save();

        $user = new User([
            'firstname' => $firstname,
            'lastname' => $lastname,
            'username'=>(new ManageIdentify)->buildIdentify(),
            'email' => $email,
            'email_verified_at' => now(),
            'password' => bcrypt('secret'),
            'avatar' => 'avatar.png',
            'gender_id' => Referentiel::where("code", CodeReferentiel::HOMME)->where("type",TypeReferentiel::GENDER)->first()->id
        ]);

        $student->user()->save($user);

    }

    public function createSubject($name,$code,$classe=null){
        Subject::create([
            'name' => $name,
            'code' => $code,
            'classe_id' => isset($classe) ? Classe::where('code',$classe)->first()->id : null
        ]);
    }
}
